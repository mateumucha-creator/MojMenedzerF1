# Mój Menedżer F1 – budowanie APK

W repozytorium GitHub umieść oba elementy z tej paczki zachowując ścieżki:
- `.github/workflows/build-apk.yml`
- `MojMenedzerF1-Android-project.zip`

Po dodaniu plików GitHub Actions automatycznie zbuduje APK. Plik `app-debug.apk` będzie dostępny w zakładce Actions w artefakcie `Moj-Menedzer-F1-APK`.

Workflow używa Javy 17, Gradle 8.9 i Android SDK 35. APK debug nie jest podpisany do publikacji w Google Play, ale można go zainstalować na własnym telefonie po zezwoleniu na instalację z danego źródła.
